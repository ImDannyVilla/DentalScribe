import json
import boto3
import os
from datetime import datetime, timedelta

bedrock = boto3.client('bedrock-runtime', region_name=os.environ['AWS_REGION'])
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(os.environ['NOTES_TABLE'])

SYSTEM_PROMPT = """You are an expert Dental Scribe. Convert this conversation transcript into a comprehensive visit summary.

IMPORTANT: Capture ALL conversation content, not just clinical procedures. Include:
- Patient complaints, concerns, questions, and discussions
- Treatment explanations given to patient
- Patient understanding and agreements
- Any clinical procedures performed
- Financial discussions
- Scheduling and follow-up conversations

FORMAT:
**Patient Communication:**
- Chief Concern: [What patient reported/complained about]
- Discussion Summary: [Key points discussed with patient]
- Patient Understanding: [Confirmed patient understood treatment/costs/risks]
- Agreements: [What patient agreed to or declined]

**Clinical Details:** (if applicable)
- Tooth/Teeth: [Universal numbering #1-#32, if specific teeth discussed]
- Procedure: [If any procedure was performed]
- Findings: [Clinical observations]
- Materials Used: [If applicable]
- Anesthetic: [If used]

**Follow-up:**
- Next Steps: [Next appointment, instructions, or actions needed]
- Patient Questions: [Any questions patient asked]

GUIDELINES:
- Write in clear, professional language
- Capture the complete conversation, not just clinical details
- Use standard dental abbreviations when appropriate (MOD, PFM, RCT, etc.)
- If no clinical procedure was performed, focus on the consultation/discussion
- Always document what the patient said and understood"""


def lambda_handler(event, context):
    try:
        body = json.loads(event['body'])
        transcript = body['transcript']
        patient_name = body.get('patient_name', 'UNKNOWN')

        # Get user from Cognito claims
        user_id = event['requestContext']['authorizer']['claims']['sub']
        user_email = event['requestContext']['authorizer']['claims']['email']

        # Generate note using Bedrock
        bedrock_body = json.dumps({
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 2000,
            "messages": [{
                "role": "user",
                "content": f"{SYSTEM_PROMPT}\n\nTRANSCRIPT:\n{transcript}"
            }],
            "temperature": 0
        })

        response = bedrock.invoke_model(
            modelId='us.anthropic.claude-3-5-sonnet-20241022-v2:0',
            contentType='application/json',
            accept='application/json',
            body=bedrock_body
        )

        response_body = json.loads(response['body'].read())
        visit_summary = response_body['content'][0]['text']

        # Auto-save to DynamoDB
        timestamp = datetime.utcnow().isoformat()
        ttl = int((datetime.now() + timedelta(days=365)).timestamp())

        item = {
            'user_id': user_id,
            'timestamp': timestamp,
            'patient_name': patient_name,
            'transcript': transcript,
            'soap_note': visit_summary,
            'provider_email': user_email,
            'ttl': ttl,
            'created_at': timestamp
        }

        table.put_item(Item=item)

        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'note': visit_summary,
                'timestamp': timestamp,
                'note_id': f"{user_id}#{timestamp}",
                'saved': True
            })
        }

    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'error': str(e)})
        }